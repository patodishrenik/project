package com.payu.request;

import java.math.BigDecimal;

import com.payu.model.Transaction.CreditSource;
import com.payu.model.Transaction.DebitSource;

public class TransactionRequest {

	private String email;
	private BigDecimal amount;
	private CreditSource creditSource;
	private DebitSource debitSource;
	private long transactionReference;

	public TransactionRequest(String email, BigDecimal amount, CreditSource creditSource, DebitSource debitSource,
			long transactionReference) {
		this.email = email;
		this.amount = amount;
		this.creditSource = creditSource;
		this.debitSource = debitSource;
		this.transactionReference = transactionReference;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public CreditSource getCreditSource() {
		return creditSource;
	}

	public void setCreditSource(CreditSource cSource) {
		this.creditSource = cSource;
	}

	public DebitSource getDebitSource() {
		return debitSource;
	}

	public void setDebitSource(DebitSource dSource) {
		this.debitSource = dSource;
	}

	public long getTransactionReference() {
		return transactionReference;
	}

	public void setTransactionReference(long transactionReference) {
		this.transactionReference = transactionReference;
	}
}
