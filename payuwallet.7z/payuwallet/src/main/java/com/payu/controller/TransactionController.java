package com.payu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.payu.exception.DbException;
import com.payu.exception.UserNotFoundException;
import com.payu.model.Transaction;
import com.payu.service.TransactionService;

@Controller
@RequestMapping(value = "/transaction")
public class TransactionController extends AbstractController{

	@Autowired
	private TransactionService transactionService;

	/**
	 * getting transactions
	 * 
	 * @return
	 * @throws DbException
	 * @throws UserNotFoundException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public @ResponseBody List<Transaction> getTransactions(@RequestParam(value = "email") String email,
			@RequestParam(value = "limit", defaultValue = "10") int limit,
			@RequestParam(value = "time", defaultValue = "0") long time) throws UserNotFoundException, DbException {
		if (time <= 0) {
			time = System.currentTimeMillis();
		}
		if (limit < 0){
			limit = 0;
		}
		return transactionService.getTransactions(email, limit, time);
	}

}