package com.payu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.payu.authservice.Authenticator;

/**
 * Intercepts all request and pass it to authentication module for validation
 * 
 *
 */
public class RequestInterceptor implements HandlerInterceptor {

	@Autowired
	private Authenticator authenticator;

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
	}

	@Override
	public boolean preHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2) throws Exception {
		// if request is unauthenticated/invalid no need for further processing,
		// throws AuthException
		return authenticator.authenticateHttpRequest(arg0);
	}

}
