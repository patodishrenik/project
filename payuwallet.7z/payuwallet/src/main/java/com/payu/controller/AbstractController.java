package com.payu.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.payu.exception.AuthException;
import com.payu.exception.CreditOverflowException;
import com.payu.exception.DbException;
import com.payu.exception.DebitOverflowException;
import com.payu.exception.RequestParamsValidationException;
import com.payu.exception.TransFrequencyThresholdException;
import com.payu.exception.UserNotFoundException;
import com.payu.exception.WalletNotFoundException;

/**
 * common exception handlers for controllers good place to do logging
 * 
 *
 */
public abstract class AbstractController {

	public static final class ExceptionInfo {
		private String message;

		public ExceptionInfo(String msg) {
			this.message = msg;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}
	}

	@ExceptionHandler(AuthException.class)
	public ResponseEntity<ExceptionInfo> handleAuthException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Authorization failed"),
				HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(CreditOverflowException.class)
	public ResponseEntity<ExceptionInfo> handleCreditOverFlowException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Monthly credit limit exceeded"),
				HttpStatus.OK);
	}

	@ExceptionHandler(DbException.class)
	public ResponseEntity<ExceptionInfo> handleDbException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Database Error"), HttpStatus.OK);
	}

	@ExceptionHandler(DebitOverflowException.class)
	public ResponseEntity<ExceptionInfo> handleDebitOverflowException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Amount not available in wallet"),
				HttpStatus.OK);
	}

	@ExceptionHandler(RequestParamsValidationException.class)
	public ResponseEntity<ExceptionInfo> handleRequestParamValidationException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Bad request params"),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TransFrequencyThresholdException.class)
	public ResponseEntity<ExceptionInfo> handleTransactionFrequencyException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Transaction frequency exceeded"),
				HttpStatus.OK);
	}

	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ExceptionInfo> handleUserNotFoundException() {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("User not found"),
				HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(WalletNotFoundException.class)
	public ResponseEntity<ExceptionInfo> handleWalletNotFoundException(WalletNotFoundException e) {
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("User wallet not found"),
				HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionInfo> handleGenericException(Exception e) {
		e.printStackTrace();
		return new ResponseEntity<AbstractController.ExceptionInfo>(new ExceptionInfo("Internal Error"), HttpStatus.OK);
	}

}
