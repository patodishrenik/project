package com.payu.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.payu.exception.CreditOverflowException;
import com.payu.exception.DbException;
import com.payu.exception.DebitOverflowException;
import com.payu.exception.RequestParamsValidationException;
import com.payu.exception.TransFrequencyThresholdException;
import com.payu.exception.UserNotFoundException;
import com.payu.exception.WalletNotFoundException;
import com.payu.model.Transaction;
import com.payu.model.Transaction.CreditSource;
import com.payu.model.Transaction.DebitSource;
import com.payu.model.Wallet;
import com.payu.request.TransactionRequest;
import com.payu.service.WalletService;

@Controller
@RequestMapping(value = "/wallet")
public class WalletController extends AbstractController {

	@Autowired
	private WalletService walletService;

	/**
	 * loading wallet with money
	 * 
	 * @throws DbException
	 * @throws UserNotFoundException
	 * @throws CreditOverflowException
	 * @throws RequestParamsValidationException
	 * @throws WalletNotFoundException
	 */
	@RequestMapping(value = "/load", method = RequestMethod.POST)
	public @ResponseBody Transaction loadWallet(@RequestParam("email") String email,
			@RequestParam("amount") BigDecimal amount, @RequestParam("creditSource") CreditSource creditSource,
			@RequestParam("transactionReference") long transactionReference) throws UserNotFoundException, DbException,
					WalletNotFoundException, RequestParamsValidationException, CreditOverflowException {

		return walletService
				.loadWallet(new TransactionRequest(email, amount, creditSource, null, transactionReference));
	}

	/**
	 * unloading wallet with money
	 * 
	 * @throws TransFrequencyThresholdException
	 * @throws WalletNotFoundException
	 * @throws RequestParamsValidationException
	 * @throws DbException
	 * @throws UserNotFoundException
	 * @throws DebitOverflowException
	 */
	@RequestMapping(value = "/unload", method = RequestMethod.POST)
	public @ResponseBody Transaction unloadWallet(@RequestParam("email") String email,
			@RequestParam("amount") BigDecimal amount, @RequestParam("debitSource") DebitSource debitSource,
			@RequestParam("transactionReference") long transactionReference)
					throws UserNotFoundException, DbException, RequestParamsValidationException,
					WalletNotFoundException, TransFrequencyThresholdException, DebitOverflowException {
		return walletService
				.unloadWallet(new TransactionRequest(email, amount, null, debitSource, transactionReference));
	}

	/**
	 * get wallet status
	 * 
	 * @throws DbException
	 * @throws UserNotFoundException
	 * @throws WalletNotFoundException
	 */
	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public @ResponseBody Wallet getWalletStatus(@RequestParam(value = "email") String email)
			throws UserNotFoundException, DbException, WalletNotFoundException {
		return walletService.getWallet(email);
	}
}
