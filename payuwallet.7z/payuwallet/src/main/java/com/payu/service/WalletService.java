package com.payu.service;

import com.payu.exception.CreditOverflowException;
import com.payu.exception.DbException;
import com.payu.exception.DebitOverflowException;
import com.payu.exception.TransFrequencyThresholdException;
import com.payu.exception.RequestParamsValidationException;
import com.payu.exception.UserNotFoundException;
import com.payu.exception.WalletNotFoundException;
import com.payu.model.Transaction;
import com.payu.model.Wallet;
import com.payu.request.TransactionRequest;

/**
 * Wallet services
 * 
 *
 */
public interface WalletService {

	Transaction loadWallet(TransactionRequest request) throws UserNotFoundException, DbException,
			WalletNotFoundException, RequestParamsValidationException, CreditOverflowException;

	Transaction unloadWallet(TransactionRequest request)
			throws UserNotFoundException, DbException, RequestParamsValidationException, WalletNotFoundException,
			TransFrequencyThresholdException, DebitOverflowException;

	Wallet getWallet(String email) throws UserNotFoundException, DbException, WalletNotFoundException;
}
