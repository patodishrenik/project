package com.payu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.payu.authservice.Authenticator;
import com.payu.dao.TransactionDao;
import com.payu.exception.DbException;
import com.payu.exception.UserNotFoundException;
import com.payu.model.Transaction;
import com.payu.model.User;
import com.payu.service.TransactionService;

@Service
@Transactional(readOnly = true)
public class TransactionServiceImpl implements TransactionService {
	
	@Autowired
	private TransactionDao transactionDao;
	
	@Autowired
	private Authenticator authenticator;
	
	@Override
	public List<Transaction> getTransactions(String email, int limit, long time) throws UserNotFoundException, DbException {
		User user = authenticator.getUser(email);
		return transactionDao.getTransactionsBeforeTime(user.getId(), limit, time);
	}
}
