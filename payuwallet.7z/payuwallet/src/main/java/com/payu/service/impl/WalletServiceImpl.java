package com.payu.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.payu.AppContants;
import com.payu.authservice.Authenticator;
import com.payu.dao.TransactionDao;
import com.payu.dao.WalletDao;
import com.payu.exception.CreditOverflowException;
import com.payu.exception.DbException;
import com.payu.exception.DebitOverflowException;
import com.payu.exception.TransFrequencyThresholdException;
import com.payu.exception.RequestParamsValidationException;
import com.payu.exception.UserNotFoundException;
import com.payu.exception.WalletNotFoundException;
import com.payu.model.User;
import com.payu.model.Transaction;
import com.payu.model.Transaction.CreditSource;
import com.payu.model.Transaction.DebitSource;
import com.payu.model.Wallet;
import com.payu.request.TransactionRequest;
import com.payu.service.WalletService;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.SERIALIZABLE, rollbackFor = {
		DbException.class })
public class WalletServiceImpl implements WalletService {

	@Autowired
	private Authenticator authenticator;

	@Autowired
	private WalletDao walletDao;

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private AppContants constants;

	@Override
	public Transaction loadWallet(TransactionRequest request) throws UserNotFoundException, DbException,
			WalletNotFoundException, RequestParamsValidationException, CreditOverflowException {

		User user = authenticator.getUser(request.getEmail());
		validateRequest(request, user, true);
		Wallet wallet = walletDao.getWallet(user.getId());
		if (wallet == null) {
			throw new WalletNotFoundException("No wallet for the user");
		}

		if (!request.getCreditSource().equals(CreditSource.REFUND)) {
			// in case of refund it should go to wallet even if credit limit
			// exceeds
			// credit limit is based on calendar months and not on basis rolling
			// time
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
			List<Transaction> pastTransactions = transactionDao.getCreditTransactionsAfterTime(user.getId(),
					calendar.getTimeInMillis());
			BigDecimal pastCreditVal = BigDecimal.valueOf(0L);
			for (Transaction trans : pastTransactions) {
				pastCreditVal = pastCreditVal.add(trans.getAmount());
			}
			pastCreditVal = pastCreditVal.add(request.getAmount());
			if (pastCreditVal.compareTo(BigDecimal.valueOf(constants.getMaxCreditLimitMonthly())) > 0) {
				throw new CreditOverflowException(
						"Monthly limit of " + constants.getMaxCreditLimitMonthly() + " exceeded");
			}
		}

		Transaction transaction = new Transaction();
		transaction.setUser(user);
		transaction.setCreditSource(request.getCreditSource());
		transaction.setAmount(request.getAmount());
		transaction.setTransactionReference(request.getTransactionReference());
		long transactionId = transactionDao.insert(transaction);

		BigDecimal amount = wallet.getAmount().add(request.getAmount());
		wallet.setAmount(amount);
		wallet.setLastTransactionAt(transaction.getTransactionDate());
		walletDao.update(wallet);
		transaction.setId(transactionId);
		return transaction;
	}

	private void validateRequest(TransactionRequest request, User user, boolean isCredit)
			throws RequestParamsValidationException {
		if (request.getAmount().compareTo(BigDecimal.valueOf(0L)) < 0) {
			throw new RequestParamsValidationException("Amount can not be negative");
		}
		if (request.getDebitSource() == null && request.getCreditSource() == null) {
			throw new RequestParamsValidationException("Invalid transaction type");
		}
		if (isCredit && request.getCreditSource() == null) {
			throw new RequestParamsValidationException("Invalid credit source");
		}
		if (!isCredit && request.getDebitSource() == null) {
			throw new RequestParamsValidationException("Invalid debit source");
		}
	}

	@Override
	public Transaction unloadWallet(TransactionRequest request)
			throws UserNotFoundException, DbException, RequestParamsValidationException, WalletNotFoundException,
			TransFrequencyThresholdException, DebitOverflowException {

		User user = authenticator.getUser(request.getEmail());
		validateRequest(request, user, false);
		Wallet wallet = walletDao.getWallet(user.getId());
		if (wallet == null) {
			throw new WalletNotFoundException("No wallet for the user");
		}

		long lastTransactionTime = wallet.getLastTransactionAt();
		// in case of transactions lastTransaction should have difference more than defined threshold
		// also concurrent transactions request to be stopped by locking on the row
		if (System.currentTimeMillis() - lastTransactionTime <= constants.getTransactionDurationThresholdMillis()) {
			throw new TransFrequencyThresholdException("Too many transaction requests within small time frame");
		}
		
		if (wallet.getAmount().compareTo(request.getAmount()) < 0) {
			throw new DebitOverflowException("Wallet amount is less than requested amount");
		}
		
		if (request.getDebitSource().equals(DebitSource.WITHDRAWAL)) {
			List<Transaction> transactions = transactionDao.getNonCreditCardTransactions(user.getId());
			BigDecimal nonCreditAmount = BigDecimal.valueOf(0L);
			BigDecimal amount = request.getAmount();
			for (Transaction trans : transactions) {
				nonCreditAmount = nonCreditAmount.add(trans.getAmount());
			}
			// if non credit card amount covers the amount requested, we follow
			// through.
			// else find the diff between non credit and amount requested. and
			// for that diff add a 2% interest
			if (nonCreditAmount.compareTo(amount) < 0) {
				BigDecimal diff = amount.subtract(nonCreditAmount);
				amount = amount.add(diff.multiply(BigDecimal.valueOf(1.02d)));
			}
			request.setAmount(amount);
		}

		// TODO : if credit card withdrawal add 2%
		Transaction transaction = new Transaction();
		transaction.setUser(user);
		transaction.setDebitSource(request.getDebitSource());
		transaction.setAmount(request.getAmount());
		transaction.setTransactionReference(request.getTransactionReference());
		long transactionId = transactionDao.insert(transaction);

		BigDecimal amount = wallet.getAmount().subtract(request.getAmount());
		wallet.setAmount(amount);
		wallet.setLastTransactionAt(transaction.getTransactionDate());
		walletDao.update(wallet);

		transaction.setId(transactionId);
		return transaction;
	}

	@Override
	public Wallet getWallet(String email) throws UserNotFoundException, DbException, WalletNotFoundException {
		User user = authenticator.getUser(email);
		Wallet wallet = walletDao.getWallet(user.getId());
		if (wallet == null){
			throw new WalletNotFoundException("No wallet for the user");
		}
		return wallet;
	}
}
