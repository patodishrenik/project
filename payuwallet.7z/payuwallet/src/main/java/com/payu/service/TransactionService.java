package com.payu.service;

import java.util.List;

import com.payu.exception.DbException;
import com.payu.exception.UserNotFoundException;
import com.payu.model.Transaction;
/**
 * Transaction services
 * 
 *
 */
public interface TransactionService {
	
	List<Transaction> getTransactions(String email, int limit, long time) throws UserNotFoundException, DbException;
}
