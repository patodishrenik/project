package com.payu;

/**
 * Holder class for app specific contants
 * 
 *
 */
public final class AppContants {

	private final long maxCreditLimitMonthly;

	private final long transDurationThreshold;

	public AppContants(long maxCreditLimitMonthly, long debitDurationThreshold) {
		this.maxCreditLimitMonthly = maxCreditLimitMonthly;
		this.transDurationThreshold = debitDurationThreshold;
	}

	public long getMaxCreditLimitMonthly() {
		return maxCreditLimitMonthly;
	}

	public long getTransactionDurationThresholdMillis() {
		return transDurationThreshold;
	}
}
