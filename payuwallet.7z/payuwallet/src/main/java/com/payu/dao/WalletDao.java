package com.payu.dao;

import com.payu.exception.DbException;
import com.payu.model.Wallet;

/**
 * Wallet model db accessor
 * 
 *
 */
public interface WalletDao {

	long insert(Wallet wallet) throws DbException;

	void update(Wallet wallet) throws DbException;

	Wallet getWallet(long userid) throws DbException;
}
