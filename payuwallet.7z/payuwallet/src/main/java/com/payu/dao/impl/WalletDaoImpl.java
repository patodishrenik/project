package com.payu.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.payu.dao.WalletDao;
import com.payu.exception.DbException;
import com.payu.model.Wallet;

@Repository
public class WalletDaoImpl extends AbstractDao<Long, Wallet> implements WalletDao {

	@Override
	public long insert(Wallet wallet) throws DbException {
		return insertEntity(wallet);
	}

	@Override
	public void update(Wallet wallet) throws DbException {
		updateEntity(wallet);
	}
	
	@Override
	public Wallet getWallet(long userid) throws DbException {
		Criteria criteria = buildCriteria(Wallet.class);
		criteria.add(Restrictions.eq("user.id", userid));
		return queryForUnique(criteria);
	}
}
