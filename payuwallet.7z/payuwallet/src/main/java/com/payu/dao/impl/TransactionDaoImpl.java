package com.payu.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.payu.dao.TransactionDao;
import com.payu.exception.DbException;
import com.payu.model.Transaction;
import com.payu.model.Transaction.CreditSource;

@Repository
public class TransactionDaoImpl extends AbstractDao<Long, Transaction> implements TransactionDao {

	@Override
	public long insert(Transaction transaction) throws DbException {
		return insertEntity(transaction);
	}

	@Override
	public void update(Transaction transaction) throws DbException {
		updateEntity(transaction);
	}

	@Override
	public List<Transaction> getCreditTransactionsAfterTime(long userid, long time) throws DbException {
		Criteria criteria = buildCriteria(Transaction.class);
		criteria.add(Restrictions.eq("user.id", userid));
		criteria.add(Restrictions.isNotNull("creditSource"));
		criteria.add(Restrictions.gt("transactionDate", time));
		return queryForList(criteria);
	}

	@Override
	public List<Transaction> getTransactionsBeforeTime(long userid, int limit, long time) throws DbException {
		Criteria criteria = buildCriteria(Transaction.class);
		criteria.add(Restrictions.eq("user.id", userid));
		criteria.add(Restrictions.lt("transactionDate", time));
		criteria.addOrder(Order.desc("transactionDate"));
		if (limit > 0) {
			criteria.setMaxResults(limit);
		}
		return queryForList(criteria);
	}

	@Override
	public List<Transaction> getNonCreditCardTransactions(long userid) throws DbException {
		Criteria criteria = buildCriteria(Transaction.class);
		criteria.add(Restrictions.eq("user.id", userid));
		criteria.add(Restrictions.isNotNull("creditSource"));
		criteria.add(Restrictions.not(Restrictions.eq("creditSource", CreditSource.CREDIT_CARD)));
		return queryForList(criteria);
	}
}
