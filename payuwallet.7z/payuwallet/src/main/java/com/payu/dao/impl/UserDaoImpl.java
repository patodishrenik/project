package com.payu.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.payu.dao.UserDao;
import com.payu.exception.DbException;
import com.payu.model.User;

@Repository
public class UserDaoImpl extends AbstractDao<Long, User> implements UserDao {

	@Override
	public User getUserforEmail(String email) throws DbException {
		Criteria criteria = buildCriteria(User.class);
		criteria.add(Restrictions.eq("email", email));
		return queryForUnique(criteria);
	}

	@Override
	public User getUserforId(long id) throws DbException {
		return get(id, User.class);
	}
}
