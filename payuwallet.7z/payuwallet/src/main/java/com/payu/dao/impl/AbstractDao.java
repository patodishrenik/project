package com.payu.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.payu.exception.DbException;

/**
 * Common methods for all db related operations
 * 
 *
 * @param <PK>
 *            primary key typed parameter
 * @param <V>
 *            model class typed param
 */
public abstract class AbstractDao<PK extends Serializable, V> {

	@Autowired
	private SessionFactory sessionFactory;

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	protected PK insertEntity(V entity) throws DbException {
		try {
			return (PK) getSession().save(entity);
		} catch (Exception e) {
			throw new DbException(e);
		}
	}

	protected void updateEntity(V entity) throws DbException {
		try {
			getSession().update(entity);
		} catch (Exception e) {
			throw new DbException(e);
		}
	}

	protected V get(PK id, Class<V> clazz) throws DbException {
		try {
			return getSession().get(clazz, id);
		} catch (Exception e) {
			throw new DbException(e);
		}
	}

	protected List<V> queryForList(Criteria criteria) throws DbException {
		try {
			return criteria.list();
		} catch (Exception e) {
			throw new DbException(e);
		}
	}

	protected V queryForUnique(Criteria criteria) throws DbException {
		try {
			return (V) criteria.uniqueResult();
		} catch (Exception e) {
			throw new DbException(e);
		}
	}

	protected Criteria buildCriteria(Class<V> clazz) {
		return getSession().createCriteria(clazz);
	}
}
