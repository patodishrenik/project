package com.payu.dao;

import com.payu.exception.DbException;
import com.payu.model.User;
/**
 * User model db accessor
 * 
 *
 */
public interface UserDao {

	User getUserforEmail(String email) throws DbException;

	User getUserforId(long id) throws DbException;
}
