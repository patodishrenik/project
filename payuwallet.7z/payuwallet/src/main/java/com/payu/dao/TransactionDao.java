package com.payu.dao;

import java.util.List;

import com.payu.exception.DbException;
import com.payu.model.Transaction;

/**
 * Transaction model db accessor
 * 
 *
 */
public interface TransactionDao {

	long insert(Transaction transaction) throws DbException;

	void update(Transaction transaction) throws DbException;

	List<Transaction> getCreditTransactionsAfterTime(long userid, long time) throws DbException;

	List<Transaction> getTransactionsBeforeTime(long userid, int limit, long time) throws DbException;
	
	List<Transaction> getNonCreditCardTransactions(long userid) throws DbException;
}
