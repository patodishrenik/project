package com.payu.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * Model class for Wallet
 * 
 *
 */
@JsonInclude(value = Include.NON_NULL)
@Entity
@Table(name = "wallet")
public class Wallet implements Serializable{

	public static final long serialVersionUID = 1L;

	@JsonIgnore(value = true)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private long id;
	
	@OneToOne(optional= false)
	@JoinColumn(name = "uid")
	private User user;
	
	@Column(name = "amount", unique = false, nullable = false)
	private BigDecimal amount;
	
	
	@Column(name = "last_trans_at", unique = false, nullable = false)
	private long lastTransactionAt;
	
	public Wallet() {
		this.amount = BigDecimal.valueOf(0L);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public long getLastTransactionAt() {
		return lastTransactionAt;
	}

	public void setLastTransactionAt(long lastTransactionAt) {
		this.lastTransactionAt = lastTransactionAt;
	}

}
