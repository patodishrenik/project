package com.payu.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Model class for Transaction
 * 
 *
 */
@JsonInclude(value = Include.NON_NULL)
@Entity
@Table(name = "transaction")
public class Transaction implements Serializable {

	public static final long serialVersionUID = 1L;

	public enum DebitSource {
		PAYMENT, WITHDRAWAL;
	}

	public enum CreditSource {
		DEBIT_CARD, CREDIT_CARD, NET_BANKING, REFUND;
	}

	@JsonIgnore(value = true)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private long id;

	@ManyToOne(optional = false)
	@JoinColumn(name = "uid")
	private User user;

	//@JsonSerialize(using = ToStringSerializer.class)
	@Column(name = "debit_source", unique = false, nullable = true)
	private DebitSource debitSource;
	
	//@JsonSerialize(using = ToStringSerializer.class)
	@Column(name = "credit_source", unique = false, nullable = true)
	private CreditSource creditSource;

	@Column(name = "amount", unique = false, nullable = false)
	private BigDecimal amount;

	@Column(name = "trans_date", unique = false, nullable = false)
	private long transactionDate;

	@Column(name = "trans_ref", unique = true, nullable = false)
	private long transactionReference;

	public Transaction() {
		this.transactionDate = System.currentTimeMillis();
		this.amount = BigDecimal.valueOf(0L);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public DebitSource getDebitSource() {
		return debitSource;
	}

	public void setDebitSource(DebitSource type) {
		this.debitSource = type;
	}

	public CreditSource getCreditSource() {
		return creditSource;
	}

	public void setCreditSource(CreditSource source) {
		this.creditSource = source;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public long getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(long date) {
		this.transactionDate = date;
	}

	public long getTransactionReference() {
		return transactionReference;
	}

	public void setTransactionReference(long transactionReference) {
		this.transactionReference = transactionReference;
	}
}
