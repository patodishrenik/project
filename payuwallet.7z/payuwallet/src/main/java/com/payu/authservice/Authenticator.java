package com.payu.authservice;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payu.dao.UserDao;
import com.payu.exception.AuthException;
import com.payu.exception.DbException;
import com.payu.exception.UserNotFoundException;
import com.payu.model.User;

/**
 * This class mocks the methods of Auth module. Presently it returns dummy
 * values
 * 
 *
 */
@Component
public class Authenticator {

	@Autowired
	private UserDao userDao;

	/**
	 * 
	 * @param request
	 * @return true if request is authenticated
	 * @throws AuthException
	 *             if request is invalid
	 */
	public final boolean authenticateHttpRequest(HttpServletRequest request) throws AuthException {
		// TODO: authentication based on headers, auth tokens
		return true;
	}

	/**
	 * 
	 * @param email
	 * @return the user
	 * @throws UserNotFoundException
	 *             if email is invalid
	 * @throws DbException
	 */
	public final User getUser(String email) throws UserNotFoundException, DbException {
		User user = userDao.getUserforEmail(email);
		if (user == null) {
			throw new UserNotFoundException("No user found");
		}
		return user;
	}

}
