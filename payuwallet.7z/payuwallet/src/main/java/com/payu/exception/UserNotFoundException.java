package com.payu.exception;

/**
 * Exception in case user not available. Thrown by authorization module
 * 
 *
 */
public class UserNotFoundException extends Exception {

	public static final long serialVersionUID = 1L;

	public UserNotFoundException() {
		super();
	}

	public UserNotFoundException(String msg) {
		super(msg);
	}

	public UserNotFoundException(Exception e) {
		super(e);
	}
}
