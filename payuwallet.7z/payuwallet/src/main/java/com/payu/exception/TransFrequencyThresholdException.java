package com.payu.exception;

/**
 * Exception in case wallet transaction frequency is more than configured for
 * system Presently, configured value = 10000ms that means,a minimum of 10000ms has to
 * pass between subsequent transactions 
 * 
 *
 */
public class TransFrequencyThresholdException extends Exception {

	public static final long serialVersionUID = 1L;

	public TransFrequencyThresholdException() {
		super();
	}

	public TransFrequencyThresholdException(String msg) {
		super(msg);
	}

	public TransFrequencyThresholdException(Exception e) {
		super(e);
	}
}
