package com.payu.exception;

/**
 * Exception in case max credit limit is crossed
 * 
 *
 */
public class CreditOverflowException extends Exception{

	public static final long serialVersionUID = 1L;
	
	public CreditOverflowException(){
		super();
	}
	
	public CreditOverflowException(String msg){
		super(msg);
	}
	
	public CreditOverflowException(Exception e){
		super(e);
	}
}
