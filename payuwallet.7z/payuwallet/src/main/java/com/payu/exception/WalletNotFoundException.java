package com.payu.exception;

/**
 * Exception in case wallet for the user is not present in db. Should never
 * occur as assumed that wallet entry is created for each user at registration
 * time.
 * 
 *
 */
public class WalletNotFoundException extends Exception {

	public static final long serialVersionUID = 1L;

	public WalletNotFoundException() {
		super();
	}

	public WalletNotFoundException(String msg) {
		super(msg);
	}

	public WalletNotFoundException(Exception e) {
		super(e);
	}
}
