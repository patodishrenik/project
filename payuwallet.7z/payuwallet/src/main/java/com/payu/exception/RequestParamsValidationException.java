package com.payu.exception;

/**
 * Exception in case request params are invalid
 * 
 *
 */
public class RequestParamsValidationException extends Exception {

	public static final long serialVersionUID = 1L;

	public RequestParamsValidationException() {
		super();
	}

	public RequestParamsValidationException(String msg) {
		super(msg);
	}

	public RequestParamsValidationException(Exception e) {
		super(e);
	}
}
