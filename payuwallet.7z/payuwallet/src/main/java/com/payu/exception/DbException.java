package com.payu.exception;

/**
 * Exception in case db exception occurs
 * 
 *
 */
public class DbException extends Exception {

	public static final long serialVersionUID = 1L;

	public DbException() {
		super();
	}
	public DbException(String msg) {
		super(msg);
	}

	public DbException(Exception e) {
		super(e);
	}

}