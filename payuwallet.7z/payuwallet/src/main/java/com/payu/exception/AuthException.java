package com.payu.exception;

/**
 * Exception in case request is not authenticated
 * 
 *
 */
public class AuthException extends Exception {

	public static final long serialVersionUID = 1L;

	public AuthException() {
		super();
	}

	public AuthException(String msg) {
		super(msg);
	}

	public AuthException(Exception e) {
		super(e);
	}
}
