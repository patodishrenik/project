package com.payu.exception;

/**
 * Exception in case debit crosses wallet amount
 * 
 *
 */
public class DebitOverflowException extends Exception{

	public static final long serialVersionUID = 1L;
	
	public DebitOverflowException(){
		super();
	}
	
	public DebitOverflowException(String msg){
		super(msg);
	}
	
	public DebitOverflowException(Exception e){
		super(e);
	}
}
