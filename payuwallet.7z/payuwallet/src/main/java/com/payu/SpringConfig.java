package com.payu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.payu.controller.RequestInterceptor;

/**
 * Spring configurations and bean initializations
 * 
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.payu" })
@PropertySource(value = "classpath:app.properties")
public class SpringConfig extends WebMvcConfigurerAdapter {

	@Autowired
	private Environment environment;

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(converter());
		extendMessageConverters(converters);
	}

	@Bean
	HandlerInterceptor getHandler() {
		return new RequestInterceptor();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(getHandler());
	}

	@Bean
	MappingJackson2HttpMessageConverter converter() {
		return new MappingJackson2HttpMessageConverter();
	}

	@Bean
	AppContants getAppConstants() {
		long maxCreditMonthly = Long.valueOf(environment.getProperty("max.credit.limit.monthly"));
		long transDurationThreshold = Long.valueOf(environment.getProperty("trans.duration.threshold"));
		return new AppContants(maxCreditMonthly, transDurationThreshold);
	}
}