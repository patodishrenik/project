-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.26-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for payuwallet
DROP DATABASE IF EXISTS `payuwallet`;
CREATE DATABASE IF NOT EXISTS `payuwallet` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `payuwallet`;


-- Dumping structure for table payuwallet.transaction
DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL DEFAULT '0',
  `debit_source` tinyint(10) DEFAULT NULL,
  `credit_source` tinyint(10) DEFAULT NULL,
  `trans_ref` bigint(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `trans_date` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_trans` (`uid`),
  CONSTRAINT `FK_user_trans` FOREIGN KEY (`uid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='contains transactions';

-- Data exporting was unselected.


-- Dumping structure for table payuwallet.user
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='contains users';

-- Data exporting was unselected.


-- Dumping structure for table payuwallet.wallet
DROP TABLE IF EXISTS `wallet`;
CREATE TABLE IF NOT EXISTS `wallet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `last_trans_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_wallet` (`uid`),
  CONSTRAINT `FK_user_wallet` FOREIGN KEY (`uid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='contains wallets';

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
